# Logic Onstage Helper v0.6.7.12 — Stable Candidate: Geometry Fit

**Основа:** рабочая v0.6.7.10 (MOTU M4, Lyrics, Finder/Fixed order, orphan watchdog).
Это косметическая сборка **без функции записи**.

## Два исправления интерфейса

1. Левый край компактного Onstage Audio Player берётся от правого края нативного окна Lyrics (в режиме Left). В Right — от левой границы Lyrics. Используется единый код `screenLayoutFrame` в OnstageLyricsViewer.
2. Верхний край плеера совпадает с нижним краем главного окна Logic Pro. Native Lyrics Viewer через Core Graphics выбирает самое большое обычное окно Logic, игнорируя малые плагины. Когда места менее 132 pt, плеер сжимается по высоте, сохраняя доступность органов управления.

Плеер, как и прежде, не активирует себя поверх Logic. Waveform, scrubber и шкала dB сохраняются. Координаты окна плеера вычисляются один раз при первом использовании и кешируются до конца сеанса Helper. Next/Previous используют сохранённую геометрию без запросов Core Graphics. Пересчёт выполняется только при Left / Right / Second display или по команде Lyrics → Refresh window layout.

## Без изменения звука

`Player/OnstageAudioPlayer.cpp`, `Player/PeakLimiter.hpp`, `Helper/ClickGuardScheduler.cpp` и `Helper/ClickGuardSender.cpp` **побайтно идентичны** v0.6.7.10.
Не изменены: M4 бэкинг OUT 1–2, Logic мониторинг OUT 2 / OUT 3–4, AU Click Guard v0.4, Finder mode / Fixed song order, WAV Volume, dB шкала, Lyrics watchdog и таймаут.

## Установка

В GitHub Actions выбрать `Build Logic Onstage Helper v0.6.7.12 - Geometry Stable Candidate`, скачать ZIP из Artifacts, распаковать, запустить `Install_Helper_v06712_Stable_Candidate.command` из `release`.

Выполняйте пробный запуск на Mac **до** использования в выступлении. Если macOS не раскрывает геометрию Logic, применяется старая резервная зона; это будет отмечено в `PANEL_GEOMETRY`.
Проверить: PNG Lyrics слева, верхний край плеера по нижнему краю Logic, отсутствие зазора слева, hotkeys и M4 1–2.
