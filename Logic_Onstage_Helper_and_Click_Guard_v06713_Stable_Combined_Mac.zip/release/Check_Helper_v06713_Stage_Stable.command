#!/bin/bash
set -u
OUT="$HOME/Desktop/ClickGuard_Helper_v06713_Stable_Candidate_Diagnostic.txt"
{
  echo 'ClickGuard native scheduler v0.6.7.13 stage stable diagnostic'
  date
  echo '--- INSTALLED HELPER ---'
  ls -ld "$HOME/Applications/Logic Onstage Helper.app" 2>&1 || true
  BIN="$HOME/Applications/Logic Onstage Helper.app/Contents/Resources/ClickGuardScheduler"
  if [[ -f "$BIN" ]]; then file "$BIN"; lipo -archs "$BIN"; fi
  echo '--- NATIVE LYRICS VIEWER ---'
  echo 'Orphan watchdog: parent PID verified every 0.2 seconds' 
  VIEWER="$HOME/Applications/Logic Onstage Helper.app/Contents/Resources/OnstageLyricsViewer"
  if [[ -x "$VIEWER" ]]; then file "$VIEWER"; "$VIEWER" --version; for mode in left right second; do "$VIEWER" --player-geometry "$mode"; done; fi
  tail -80 "$HOME/Library/Logs/OnstageLyricsViewer.log" 2>&1 || true
  echo '--- NATIVE AUDIO PLAYER ---'
  PLY="$HOME/Applications/Logic Onstage Helper.app/Contents/Resources/OnstageAudioPlayer"
  if [[ -f "$PLY" ]]; then file "$PLY"; "$PLY" --version; "$PLY" --list; fi
  echo '--- RAW CORE AUDIO DEVICE LIST ---'
  if [[ -x "$PLY" ]]; then
    "$PLY" --list-plain 2>&1 | sed -n 'l' || true
  fi
  echo '--- NATURAL END FOCUS MODE ---'
  defaults read local.logiconstagehelper SongSelectionModeV0676 2>&1 || true
  echo '--- SELECTED DEVICE PREFS ---'
  defaults read local.logiconstagehelper NativeAudioOutputUIDV06 2>&1 || true
  defaults read local.logiconstagehelper NativeAudioOutputNameV06 2>&1 || true
  echo '--- PROCESS PATHS ---'
  ps -axo pid,ppid,command | grep -E '[L]ogic Onstage Helper|[C]lickGuardScheduler|[C]lickGuardSender|[O]nstageAudioPlayer|[O]nstageLyricsViewer' | head -30
  echo '--- NATIVE SCHEDULER LOG (last 400 lines) ---'
  tail -400 "$HOME/Library/Logs/OnstageClickGuard_NativeScheduler.log" 2>&1 || true
  echo '--- JXA MARKER AUTOMATION LOG (last 100 lines) ---'
  tail -100 "$HOME/Library/Logs/Logic Onstage Helper marker automation.log" 2>&1 || true
  echo '--- PLAYER PANEL EVENTS (last 100 matches) ---'
  grep -E 'PANEL_(CORE_READY|VISIBLE|GEOMETRY|GEOMETRY_ERROR|LIVE_LAYOUT|LIVE_LAYOUT_ERROR|CREATE_FAILED|SHOW_FAILED|CONTENT_FAILED|DB_TICK_FAILED|DB_SCALE_FAILED)|NATIVE_DB_SCALE_UI' \
    "$HOME/Library/Logs/Logic Onstage Helper marker automation.log" | tail -100 || true
  echo '--- DEVICE AND NATIVE PLAYBACK EVENTS ---'
  grep -E 'LYRICS_|SONG_MODE_|FINDER_ACTIVATE_|DEVICE_|NATIVE_AUDIO_|NATIVE_PLAYER_' \
    "$HOME/Library/Logs/Logic Onstage Helper marker automation.log" | tail -100 || true
  echo '--- END ---'
} > "$OUT" 2>&1
printf 'Diagnostic saved:\n%s\n' "$OUT"
open -R "$OUT"
read -r -p 'Enter to exit...' _ || true
