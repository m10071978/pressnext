# Logic Onstage Helper + Onstage Click Guard
## User Guide — Stable Release v0.6.7.13 / Audio Unit v0.4.0

**Scope.** This guide covers the stable, tested playback-and-lyrics configuration. **Concert recording is not included** in this release. Always make a full show rehearsal before performing with any new installation.

### 1. What is included

- **Logic Onstage Helper v0.6.7.13:** song selection, playback, cue/marker automation, native lyrics, onstage controls, and window layout.
- **Onstage Audio Player:** a Core Audio WAV player built into the Helper. It provides a live transport, waveform overview, output-device selection, seek, and manual volume adjustments.
- **Onstage Click Guard AUv2 v0.4.0:** an effect inserted in Logic Pro that briefly attenuates the selected guitar/vocal path around Helper-triggered preset/marker changes, reducing audible clicks.
- **A combined installer:** installs Helper and, when necessary, the AU component. Existing installations are backed up.

This is an **ad-hoc-signed, non-notarized distribution**, not a notarized commercial macOS package. macOS may show a security warning; use the system's normal approval mechanism only if you trust the build.

### 2. Installation

1. Quit **Logic Pro** and **Logic Onstage Helper** before installing.
2. Unzip the GitHub Actions artifact, then unzip the release ZIP inside it.
3. Open the `release` folder and run **`Install_Logic_Onstage_and_Click_Guard.command`**. If Finder does not launch a `.command` file, open Terminal, type `bash `, drag the installer file into Terminal, and press Return.
4. The script checks both bundles, creates timestamped backup ZIPs, and installs the Helper to `~/Applications/Logic Onstage Helper.app`.
5. For the AU plug-in, it first detects existing installations. If a v0.4.0 AU is already installed, the script **keeps that tested copy** by default. Otherwise it installs `Onstage Click Guard.component` in your user Components folder or replaces an existing system-wide copy if that is where the plug-in was found (administrator approval may be requested).
6. Start Logic Pro again. Open **Logic Pro → Settings → Plug-in Manager** and check the Onstage Click Guard AU if necessary.
7. Start Helper from **`~/Applications/Logic Onstage Helper.app`**, not directly from the Downloads ZIP.

**Safety:** Backups are stored in `~/Documents/Onstage Click Guard backups/`. Settings and song files are not replaced. If you have duplicate AU copies in both system and user Components directories, the installer stops rather than risk selecting the wrong version. To deliberately replace a functioning v0.4.0 AU, see the `FORCE_AU_REINSTALL=1` example in `INSTALL_NOTES_EN.md`.

### 3. First launch and macOS permissions

The Helper controls Logic and monitors shortcuts. macOS may request **Accessibility** and **Automation/Apple Events** access. Approve only those requested for this workflow in **System Settings → Privacy & Security**. If keyboard events do not reach Logic, recheck Accessibility permissions for Helper and its native scheduler. Avoid running multiple copies of Helper simultaneously.

### 4. Set up Logic Pro

1. Open your working Logic project and select the intended **Screenset**.
2. Insert **Onstage Click Guard AU** on the channel or bus carrying the affected guitar/vocal signal. Place it **after** processing whose switching can produce clicks.
3. Useful starting AU settings are **Enabled ON**, **Hotkeys: Any Helper marker**, **Reduction: −40 dB**, **Post-key hold: 15 ms**, **Fade down: 6 ms**, **Fade up: 6 ms**. Adjust only after listening and testing.
4. Confirm that your Logic marker-change shortcuts match **Helper → Hotkeys / Send Hotkey from Songname** settings. The plug-in uses `BEGIN` / `END` control messages from Helper; it is not a general-purpose mastering limiter.

The AU attenuates only the Logic signal path where it is inserted. It does not process the Helper's backing-track output.

### 5. Choose the audio engine and output

Under **Player view**, select **Playback: Onstage Audio Player** for native WAV playback. **Playback: QuickTime** remains available as an optional alternative. You can change playback engines only when no song is active.

Open **Player view → Core Audio output**, select a compatible output device, then use **Refresh connected devices** if you connect new hardware. The Helper identifies devices by Core Audio UID, not a hard-coded manufacturer. Do not switch the output mid-song: a selection made during playback takes effect on the next song.

The native player currently supports **stereo WAV** files. Its Core Audio client stream is stereo even on a multichannel interface.

**MOTU M4 tested configuration:** backing WAV plays on **OUT 1–2**. The live Logic project independently sends vocals/guitar to **OUT 3–4**, and also sends its dedicated in-ear mix to **OUT 2**. This shared use of OUT 2 is intentional. In the tested backing files, the WAV right channel is already prepared **8 dB quieter with a 300 Hz high-pass filter**. The player does not rebalance or filter the two WAV channels. Check all routing and monitoring levels before a live show.

For built-in speakers or wired headphones, choose their Core Audio output explicitly. The Helper does not silently fall back from an unavailable selected device.

### 6. Song selection and companion lyrics

Choose a WAV in Helper or open a WAV from Finder after assigning Helper as the default application for `.wav`. Each WAV may have a matching companion **JPG, JPEG, PNG, PDF, or TXT** file. Companion names should match the song's name before the extension; if your library uses suffixes for marker automation, check the available lyrics-matching feature in Helper.

The native, borderless Lyrics viewer fits images proportionally into the available area. It initially tries to fill the width, but reduces scale to fit the height when required. PDF files use PDFKit; TXT files use automatically sized text. PDF documents with multiple pages may need scrolling.

**File → Fixed song order:** after the song finishes naturally, focus returns to Helper.

**File → Finder mode:** after the song finishes naturally, Finder is activated so you can select the next WAV. On entering Finder mode, the Helper checks the macOS default `.wav` handler and requests that Launch Services set Helper as the default if needed. If macOS blocks the change, Finder → Get Info → Open with → Logic Onstage Helper → Change All is the manual fallback. Switching back to Fixed song order does not restore a previous system-wide handler.

### 7. Lyrics placement and window layout

Choose **Lyrics → Left**, **Right**, or **Second display**. In the stable geometry build, the player and lyrics windows are designed to meet without a horizontal gap. The player is placed beneath Logic's main window when there is enough space. **Lyrics → Refresh window layout** recomputes the layout after a Screenset, display, or window-position change.

Window geometry is cached for the show rather than recalculated for every song. For the best layout, position Logic **before opening the first song**. The **Hide Lyrics before song ends** submenu offers Off or 1, 2, 3, 5, and 10 seconds; the countdown should not hide lyrics while playback is paused.

### 8. Playback controls and volume

Default hotkeys are configurable under **Hotkeys**. Defaults in the v0.6.7.13 source are:

| Action | Default shortcut |
|---|---|
| Seek back / forward 10 seconds | Left / Right arrow |
| Previous / next song | Up / Down arrow |
| Pause / resume | Space |
| Stop and close song | Esc |
| Choose a song | Command-O |
| Capture the current timecode | Command-T |
| Volume down / up 2 dB | Command-Down / Command-Up |
| Quit Helper | Command-Q |

If your show uses **U** and **J** for +2/−2 dB, retain those custom assignments in the Hotkeys menu; they are not the factory defaults listed above. The player has a volume scale labeled in dB: **0 dB** corresponds to the unmodified WAV at 100%. Positive manual gain steps reach at most **+6 dB**. A lightweight peak limiter acts only during manual boosts above 100%, protecting loud transients without normalizing the entire song. The original WAV is played at 100% with the limiter bypassed.

For stage safety, use volume boosts only as emergency corrections. Check the final combined signal (including Logic's feed on M4 OUT 2) for overload.

### 9. Filename-driven marker automation

The Helper can read special marker commands and timed transitions from filenames. Tokens such as `>>`, `<<`, `>`, `<`, and `0` are mapped to Logic hotkeys. Example time tokens used by the show are `00-18-971` and `00-35-096`, denoting song time. The initial marker selection and subsequent timed changes use the same configured Logic key mappings.

**Important:** These tokens are not standard WAV metadata. Preserve your tested filename convention and back up your song library before renaming it. Check the Helper's mapping menu and test cue timing on a duplicate song before using new markers live. When seeking, the scheduler updates which events remain eligible; verify automation by listening, not only by watching timecodes.

### 10. Troubleshooting

| Symptom | Check |
|---|---|
| AU missing in Logic | Close and reopen Logic; check Settings → Plug-in Manager; ensure there is only one AU component installation. |
| No audio output | Player view → Core Audio output, device availability, stereo WAV format, hardware routing, and OUT 1–2 levels. |
| Hotkeys do nothing | Ensure Helper is running, Logic shortcuts match, and macOS Accessibility/Automation permissions are granted. |
| Lyrics misplaced | Set the Logic Screenset, then Lyrics → Refresh window layout. |
| Lyrics remains after abnormal quit | Close the viewer with `pkill -x OnstageLyricsViewer`; recent builds also contain an orphan-window watchdog. |
| Player cannot open a file | Confirm it is a valid **stereo `.wav`** and not an MP3 or unsupported container. |
| Unexpected ducking | Inspect the AU reduction/fade/hold settings, insert location, and BEGIN/END communication. |

The release includes a **`Check_Helper_v06713_Stage_Stable.command`** diagnostic utility. It can help collect scheduler, playback and process information. For support, attach its output along with the macOS version, interface name, selected engine and a short reproduction sequence.

### 11. Performance and safety checklist

Before each performance: verify the selected Core Audio device; check Logic outputs including the shared M4 OUT 2 feed; open one test WAV and verify its left/right channels; confirm the AU is enabled where expected; test at least one automatic marker change; verify Lyrics and the player do not cover Logic controls; and confirm a current backup of the previous working installer is available.

**This release does not record vocals, guitar, or backing tracks.** Recording will be developed separately after the existing playback system is frozen as a stable baseline.


### v0.6.7.13 interface changes

The waveform aligns horizontally with the **usable travel of the playback scrubber**; waveform transparency is 33% opacity. Hotkey menu labels use **Player volume up/down 2 dB**, not QuickTime. The timecode command is **Copy Timecode for <current song name>** while a song is open, and **Copy Timecode for Songname** when none is open. WAV default-app selection changes the system-wide Launch Services association only when Finder mode is selected or restored at start; it does not modify the audio engine.


### 12. Finder mode and App Translocation

Finder mode was confirmed working with the stable Helper after resolving **App Translocation**. If switching to Finder mode shows a warning that macOS did not confirm the default WAV handler, first verify that Helper is installed at `~/Applications/Logic Onstage Helper.app`. Do not launch a copy directly from a ZIP or Downloads folder.

To inspect the running executable path, open Terminal and run:

```bash
ps -axo command | grep '[L]ogic Onstage Helper.app/Contents/MacOS/droplet'
```

A path containing `AppTranslocation` means macOS is running the downloaded application in an isolated temporary location. If this persists for your own **trusted, verified** GitHub build, quit Helper, confirm its installed path, and use the appropriate macOS security-approval procedure. On some Macs, explicitly clearing the quarantine attribute from **only the trusted Helper bundle** resolves the issue:

```bash
xattr -dr com.apple.quarantine "$HOME/Applications/Logic Onstage Helper.app"
open "$HOME/Applications/Logic Onstage Helper.app"
```

Do **not** clear quarantine flags on unknown applications. Clearing quarantine is an exception for a build you recognize and trust; it is not required for every installation. After relaunch, select **File → Finder mode** and double-click a test WAV in Finder. The Helper should open it, and Finder should regain focus after the song finishes naturally.

### 13. Validated interface changes in v0.6.7.13

The user-tested v0.6.7.13 has a waveform image spanning **the usable scrubber travel** instead of the full panel, with a **33% opacity** image. The volume slider is graduated in dB and the menu commands read **Player volume up 2 dB**, **Player volume down 2 dB**, and **Copy Timecode for [song name]** (dynamic label).

**Release scope:** stable playback, Lyrics, Finder/fixed song-order modes, and Click Guard AU. No recording functionality is included.
