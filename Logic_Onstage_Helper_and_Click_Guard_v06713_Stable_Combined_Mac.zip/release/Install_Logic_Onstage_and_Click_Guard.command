#!/bin/bash
# Combined installer for the tested Helper v0.6.7.13 and Onstage Click Guard AUv2 v0.4.0.
set -euo pipefail

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo 'ERROR: This installer requires macOS.' >&2
  exit 1
fi

HERE="$(cd "$(dirname "$0")" && pwd)"
HELPER_SRC="$HERE/Logic Onstage Helper.app"
AU_SRC="$HERE/Onstage Click Guard.component"
HELPER_DST="$HOME/Applications/Logic Onstage Helper.app"
AU_USER="$HOME/Library/Audio/Plug-Ins/Components/Onstage Click Guard.component"
AU_SYSTEM="/Library/Audio/Plug-Ins/Components/Onstage Click Guard.component"
BACKUP_BASE="$HOME/Documents/Onstage Click Guard backups"

fail() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }
read_plist() {
  /usr/libexec/PlistBuddy -c "Print :$2" "$1/Contents/Info.plist" 2>/dev/null || true
}
verify_bundle() {
  local bundle="$1"
  /usr/bin/codesign --verify --deep "$bundle" || fail "Code-signing verification failed for $bundle"
}

[[ -d "$HELPER_SRC" ]] || fail 'The release folder does not contain Logic Onstage Helper.app.'
[[ -d "$AU_SRC" ]] || fail 'The release folder does not contain Onstage Click Guard.component.'
for name in OnstageAudioPlayer ClickGuardScheduler ClickGuardSender OnstageLyricsViewer; do
  [[ -x "$HELPER_SRC/Contents/Resources/$name" ]] || fail "Helper is missing native executable: $name"
done
[[ "$(read_plist "$AU_SRC" CFBundleIdentifier)" == 'org.onstageaudio.clickguard' ]] || fail 'AU bundle identifier mismatch.'
[[ "$(read_plist "$AU_SRC" CFBundleShortVersionString)" == '0.4.0' ]] || fail 'AU version mismatch: expected 0.4.0.'
verify_bundle "$AU_SRC"
verify_bundle "$HELPER_SRC"

if [[ -d '/Applications/Logic Onstage Helper.app' ]]; then
  fail 'A second Helper exists at /Applications/Logic Onstage Helper.app. Resolve that duplicate before installing.'
fi
if [[ -d "$AU_USER" && -d "$AU_SYSTEM" ]]; then
  fail 'Duplicate AU installations in both user and system Components directories. Resolve the duplicate before installing.'
fi

AU_DEST="$AU_USER"
if [[ -d "$AU_SYSTEM" ]]; then AU_DEST="$AU_SYSTEM"; fi
AU_OPERATION='install'
if [[ -d "$AU_DEST" ]]; then
  old_version="$(read_plist "$AU_DEST" CFBundleShortVersionString)"
  if [[ "$old_version" == '0.4.0' && "${FORCE_AU_REINSTALL:-0}" != '1' ]]; then
    AU_OPERATION='keep'
  elif [[ "$old_version" != '0.4.0' && "${FORCE_AU_REINSTALL:-0}" != '1' ]]; then
    fail "Installed AU version is '$old_version' (not 0.4.0). To replace explicitly, run FORCE_AU_REINSTALL=1 bash <installer-path>."
  fi
fi

printf '\nLogic Onstage Helper v0.6.7.13 + Onstage Click Guard AU v0.4.0\n'
printf 'Helper target: %s\n' "$HELPER_DST"
printf 'AU target:     %s\n' "$AU_DEST"
if [[ "$AU_OPERATION" == 'keep' ]]; then
  printf 'AU action:     KEEP existing v0.4.0 without modification\n'
else
  printf 'AU action:     INSTALL bundled v0.4.0 (backup any existing component)\n'
fi
printf '\nIMPORTANT: Quit Logic Pro and all copies of Helper before continuing.\n'
read -r -p 'Press Return to install, or Control-C to cancel... ' _

mkdir -p "$HOME/Applications" "$BACKUP_BASE"
BACKUP="$BACKUP_BASE/$(date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$BACKUP"
STAGING="$(mktemp -d "$HOME/Applications/.onstage-install.XXXXXX")"
trap 'rm -rf "$STAGING"' EXIT
/usr/bin/ditto "$HELPER_SRC" "$STAGING/Logic Onstage Helper.app"
verify_bundle "$STAGING/Logic Onstage Helper.app"

# Protect the previous Helper and stage the full replacement rather than merging app bundles.
if [[ -d "$HELPER_DST" ]]; then
  /usr/bin/ditto -c -k --sequesterRsrc --keepParent "$HELPER_DST" "$BACKUP/Logic Onstage Helper previous.zip"
  /usr/bin/unzip -tqq "$BACKUP/Logic Onstage Helper previous.zip"
  /bin/mv "$HELPER_DST" "$BACKUP/Logic Onstage Helper previous.app"
fi
if ! /bin/mv "$STAGING/Logic Onstage Helper.app" "$HELPER_DST"; then
  if [[ -d "$BACKUP/Logic Onstage Helper previous.app" && ! -d "$HELPER_DST" ]]; then
    /bin/mv "$BACKUP/Logic Onstage Helper previous.app" "$HELPER_DST"
  fi
  fail 'Could not install Helper. Previous copy has been restored if possible.'
fi
verify_bundle "$HELPER_DST"

if [[ "$AU_OPERATION" == 'install' ]]; then
  if [[ "$AU_DEST" == "$AU_SYSTEM" ]]; then
    echo 'System AU exists; administrator permission is required to update it.'
    /usr/bin/ditto -c -k --sequesterRsrc --keepParent "$AU_DEST" "$BACKUP/Onstage Click Guard previous.zip"
    /usr/bin/unzip -tqq "$BACKUP/Onstage Click Guard previous.zip"
    /usr/bin/sudo /bin/rm -rf "$AU_DEST"
    /usr/bin/sudo /usr/bin/ditto "$AU_SRC" "$AU_DEST"
    /usr/bin/sudo /usr/bin/codesign --verify --deep "$AU_DEST"
  else
    mkdir -p "$(dirname "$AU_DEST")"
    if [[ -d "$AU_DEST" ]]; then
      /usr/bin/ditto -c -k --sequesterRsrc --keepParent "$AU_DEST" "$BACKUP/Onstage Click Guard previous.zip"
      /usr/bin/unzip -tqq "$BACKUP/Onstage Click Guard previous.zip"
      /bin/mv "$AU_DEST" "$BACKUP/Onstage Click Guard previous.component"
    fi
    if ! /usr/bin/ditto "$AU_SRC" "$AU_DEST"; then
      if [[ -d "$BACKUP/Onstage Click Guard previous.component" && ! -d "$AU_DEST" ]]; then
        /bin/mv "$BACKUP/Onstage Click Guard previous.component" "$AU_DEST"
      fi
      fail 'Could not install Audio Unit. Previous user-level component has been restored if possible.'
    fi
    verify_bundle "$AU_DEST"
  fi
fi

printf '\nInstallation complete.\n'
printf 'Helper: %s\n' "$HELPER_DST"
printf 'AU:     %s\n' "$AU_DEST"
printf 'Backups: %s\n' "$BACKUP"
printf 'Next: Launch Logic Pro, confirm Onstage Click Guard in Plug-in Manager, and rehearse routing.\n'
printf 'The Helper remains ad-hoc signed and this package is not Apple-notarized.\n'
read -r -p 'Press Return to close... ' _ || true
