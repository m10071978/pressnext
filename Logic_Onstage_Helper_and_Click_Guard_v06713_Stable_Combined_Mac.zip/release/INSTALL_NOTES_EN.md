# Combined Installation — Logic Onstage Helper v0.6.7.13 + Onstage Click Guard AU v0.4.0

This package contains both bundles and one installer: `Install_Logic_Onstage_and_Click_Guard.command`.

## Installation locations

- Helper: `~/Applications/Logic Onstage Helper.app`
- AU, if no AU is already installed: `~/Library/Audio/Plug-Ins/Components/Onstage Click Guard.component`
- AU, if already installed system-wide: `/Library/Audio/Plug-Ins/Components/Onstage Click Guard.component` (requires admin password)
- Backups: `~/Documents/Onstage Click Guard backups/<timestamp>/`

**If v0.4.0 is already installed, the installer preserves it by default.** This minimizes risk for a tested stage setup. A new Mac receives the bundled AU automatically. If an AU with a different version is installed, the installer stops until you explicitly authorize replacement and makes a backup.

To force replacement of an already installed 0.4.0 copy (only when you explicitly want it), quit Logic and Helper, then run in Terminal:

```bash
FORCE_AU_REINSTALL=1 bash '/path/to/release/Install_Logic_Onstage_and_Click_Guard.command'
```

Do not run multiple Helpers from different locations. Close Logic and Helper before installing, then restart Logic. This distribution is signed ad hoc and is not notarized; macOS may request security approval.

The included AU is the existing signed **v0.4.0 binary extracted from the original archive** (not rebuilt from JUCE). The workflow checks the plug-in bundle identifier, version, and macOS code signature. Its Google Drive source must be shared as **Anyone with the link — Viewer**. If the download is blocked, upload the same ZIP to `assets/Onstage_Click_Guard_AU_v0.4.zip` in the GitHub repository, then re-run the workflow. The installer keeps an installed v0.4.0 AU unless explicitly forced to replace it.


## App Translocation / default WAV handler

If the Helper opens from an `AppTranslocation` path, macOS may not register its permanent bundle as the `.wav` handler. Start the installed application from `~/Applications` and consult Section 12 of `USER_GUIDE_EN.md`. Only remove the quarantine attribute when you trust and have verified your GitHub Actions build; do not bypass Gatekeeper for untrusted software.

## Stable-release status

The playback/lyrics Helper v0.6.7.13 was user-tested with MOTU M4, including the shared OUT 2 monitor routing. The combined Installer is produced by GitHub Actions and still requires one successful combined-build and installation test. The AU v0.4.0 component is included from the original published archive without rebuilding its DSP. This release intentionally contains no recording function.
