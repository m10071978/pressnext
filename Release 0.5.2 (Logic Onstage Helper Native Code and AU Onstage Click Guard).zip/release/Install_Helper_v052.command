#!/bin/bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SOURCE="$HERE/Logic Onstage Helper.app"
DEST="$HOME/Applications/Logic Onstage Helper.app"
BACKUP="$HOME/Documents/Onstage Click Guard backups/$(date +%Y%m%d-%H%M%S)"
if [[ ! -d "$SOURCE" ]] || [[ ! -x "$SOURCE/Contents/Resources/ClickGuardScheduler" ]]; then
  echo 'ОШИБКА: нет собранного Helper v0.5.2 или ClickGuardScheduler.'
  read -r -p 'Enter для выхода...' _ || true; exit 1
fi
if [[ -d '/Applications/Logic Onstage Helper.app' ]]; then
  echo 'Обнаружена вторая копия Helper в /Applications. Убери её и повтори.'
  read -r -p 'Enter для выхода...' _ || true; exit 1
fi
read -r -p 'Закрой Helper и Logic; Enter для установки...' _
mkdir -p "$HOME/Applications" "$BACKUP"
if [[ -d "$DEST" ]]; then
  /usr/bin/ditto -c -k --keepParent "$DEST" "$BACKUP/Logic Onstage Helper previous backup.zip"
  /usr/bin/unzip -tqq "$BACKUP/Logic Onstage Helper previous backup.zip"
  /bin/rm -rf "$DEST"
fi
/usr/bin/ditto "$SOURCE" "$DEST"
/usr/bin/codesign --verify --deep "$DEST"
echo "Установлен Helper v0.5.2: $DEST"
echo "Резервная копия: $BACKUP"
echo 'AU v0.4 заменять НЕ НУЖНО.'
echo 'В Sequoia возможен новый запрос Accessibility; отдельно проверь ClickGuardScheduler.'
echo 'Если macOS откроет приложение из AppTranslocation, собери диагностику.'
read -r -p 'Enter для выхода...' _ || true
