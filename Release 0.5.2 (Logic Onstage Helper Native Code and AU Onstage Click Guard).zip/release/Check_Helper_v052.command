#!/bin/bash
set -u
OUT="$HOME/Desktop/ClickGuard_Helper_v052_Diagnostic.txt"
{
  echo 'ClickGuard native scheduler v0.5.2 diagnostic'
  date
  echo '--- INSTALLED HELPER ---'
  ls -ld "$HOME/Applications/Logic Onstage Helper.app" 2>&1 || true
  BIN="$HOME/Applications/Logic Onstage Helper.app/Contents/Resources/ClickGuardScheduler"
  if [[ -f "$BIN" ]]; then file "$BIN"; lipo -archs "$BIN"; fi
  echo '--- PROCESS PATHS ---'
  ps -axo pid,ppid,command | grep -E '[L]ogic Onstage Helper|[C]lickGuardScheduler|[C]lickGuardSender' | head -30
  echo '--- NATIVE SCHEDULER LOG (last 400 lines) ---'
  tail -400 "$HOME/Library/Logs/OnstageClickGuard_NativeScheduler.log" 2>&1 || true
  echo '--- JXA MARKER AUTOMATION LOG (last 100 lines) ---'
  tail -100 "$HOME/Library/Logs/Logic Onstage Helper marker automation.log" 2>&1 || true
  echo '--- END ---'
} > "$OUT" 2>&1
printf 'Diagnostic saved:\n%s\n' "$OUT"
open -R "$OUT"
read -r -p 'Enter to exit...' _ || true
